using $safeprojectname$.Features.Device.ViewModels;
using MauiCrudApp.Common.Views;

namespace $safeprojectname$.Features.Device.Views;

public partial class DeviceConnectPage : PageBase
{
    public DeviceConnectPage(DeviceConnectViewModel viewModel) : base(viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}