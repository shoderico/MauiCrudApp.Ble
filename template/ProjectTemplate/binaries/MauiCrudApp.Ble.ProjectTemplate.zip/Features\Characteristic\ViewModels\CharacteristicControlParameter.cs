namespace $safeprojectname$.Features.Characteristic.ViewModels;

public class CharacteristicControlParameter
{
}
