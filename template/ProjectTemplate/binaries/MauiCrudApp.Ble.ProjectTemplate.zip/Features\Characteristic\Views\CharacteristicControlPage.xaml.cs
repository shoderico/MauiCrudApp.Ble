using $safeprojectname$.Features.Characteristic.ViewModels;
using MauiCrudApp.Common.Views;

namespace $safeprojectname$.Features.Characteristic.Views;

public partial class CharacteristicControlPage : PageBase
{
    public CharacteristicControlPage(CharacteristicControlViewModel viewModel) : base(viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}