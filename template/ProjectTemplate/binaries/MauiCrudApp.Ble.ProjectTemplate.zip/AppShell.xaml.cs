using MauiCrudApp.Common.Controls;
using MauiCrudApp.Common.Interfaces;

namespace $safeprojectname$
{
    public partial class AppShell : ShellBase
    {
        public AppShell(IDialogService dialogService) : base(dialogService)
        {
            InitializeComponent();
        }
    }
}
