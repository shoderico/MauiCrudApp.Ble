namespace $safeprojectname$.Features.Device.ViewModels;

public class DeviceConnectParameter
{
}
